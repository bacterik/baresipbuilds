
int unixsock_listen_fd(re_sock_t *fdp, const struct sa *sock);
